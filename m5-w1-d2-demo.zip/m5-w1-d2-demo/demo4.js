//Component example with Event handlers


ReactDOM.render(<Football />, document.getElementById('root'));