//functional example and adding Events

  
  
  ReactDOM.render(myelement, document.getElementById('root'));