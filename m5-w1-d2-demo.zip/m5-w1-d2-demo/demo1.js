class Car extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      // add variables here
    };
  }
  render() {
    return ( 
      // render variables here
    );
  }
}

ReactDOM.render(<Car />, document.getElementById('root'));


